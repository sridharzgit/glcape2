# ImgLab Features:

### Auto suggestion

![Auto suggestion](/img/imglab-autosuggestion.gif)

### Plugins

![Plugins](/img/imglab-fpp.gif)

### Different Shapes

![Polygons](/img/imglab-polygon.gif)

### Keyboard Shortcuts:

![Hotkeys](/img/imglab-hotkeys.gif)

### Zoom In/Out:

![Zoom](/img/imglab-zoom.gif)

### Copy/Paste Labels Across Images:

DEMONSTRATION GIF NOT YET AVAILABLE.


Check [video](https://youtu.be/Y-bJo_ylHTw) tutorial/demonstration for more details.
