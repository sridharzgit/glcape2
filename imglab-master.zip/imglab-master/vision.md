# Screen Design

![Image labeling tool imglab Screen Design](img/imglab_vision.png)

* Project data will be saved in निम्न (nimn) format with all the information. This data can be transformed to other formats.
* ActionBar: Action bar contains options related to a tool.
* ToolBar is devided into 3 parts.
    * Import /Export
    * Zoom in/out, move
    * Labelling tools
* 