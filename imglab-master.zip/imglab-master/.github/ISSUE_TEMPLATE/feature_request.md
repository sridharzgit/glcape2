---
name: Feature request
about: Suggest an idea for this project

---

<!-- Tell us what feature you're looking for and how it can help you and others in general. -->


> [Watch](https://github.com/NaturalIntelligence/imglab/watchers) for changes, or [Bookmark](https://github.com/NaturalIntelligence/imglab/stargazers) for easy discovery.
> [Fund](https://www.patreon.com/bePatron?u=9531404) this project for new features and maintenance.
> [Showcase] your project with us by raising an issue
